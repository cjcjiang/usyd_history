package cjcjiang.lab.notelab;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ArrayList<Note> arrayOfNotes;
    ListView listView;
    UsersAdapter adapter;

    //This request code is for the Add New button
    private final int REQUEST_CODE = 233;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        arrayOfNotes = new ArrayList<Note>();

        //Get all of the notes from the database
        readNotesFromDatabase();

        // Create the adapter to convert the array to views
        adapter = new UsersAdapter(this, arrayOfNotes);
        // Attach the adapter to a ListView
        listView = (ListView) findViewById(R.id.listView);
        listView.setAdapter(adapter);

        //pop up the dialog when user long click
        setupListViewListener();

    }

    public void editNote(View view) {
        // Jump to the EditActivity
        Intent intent = new Intent(this, EditActivity.class);
        startActivityForResult(intent, REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        // To receive the new note transfered from the EditActivity
        if (resultCode == RESULT_OK && requestCode == REQUEST_CODE) {
            // Extract the new note from the intent
            Note note = (Note)intent.getSerializableExtra("New Note");
            arrayOfNotes.add(note);
            //Save the new note to the database
            saveNotesToDatabase();
            //Refresh the listView to display the new note
            adapter.notifyDataSetChanged();

        }
    }

    private void readNotesFromDatabase() {
        //read saved notes from the database
        List<Note> notesFromORM = Note.listAll(Note.class);
        arrayOfNotes = new ArrayList<Note>();
        if (notesFromORM != null & notesFromORM.size() > 0) {
            for (Note note : notesFromORM) {
                arrayOfNotes.add(note);
            }
        }
    }

    private void saveNotesToDatabase() {
        //save all the notes to the database
        Note.deleteAll(Note.class);
        for (Note note:arrayOfNotes){
            note.save();
        }
    }

    private void setupListViewListener() {

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            //When user long click the note, show this dialog
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long rowId) {
                Log.i("MainActivity", "Long Clicked item " + position);
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle(R.string.dialog_delete_title).setMessage(R.string.dialog_delete_msg)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //Delete the note
                                arrayOfNotes.remove(position);
                                adapter.notifyDataSetChanged();
                                saveNotesToDatabase();

                            }
                        }).setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //User cancelled the dialog
                        // nothing happens
                    }
                });
                builder.create().show();
                return true;
            }
        });
    }


}
