package cjcjiang.lab.notelab;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;

public class EditActivity extends AppCompatActivity {

    EditText titleEditText;
    EditText messageEditText;
    TextView timeTextView;
    Calendar timeOfCreation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        titleEditText = (EditText)findViewById(R.id.title_editText);

        timeTextView = (TextView) findViewById(R.id.time_textView);
        //Use calendar to get the current system time
        timeOfCreation = Calendar.getInstance();
        String time = timeOfCreation.getTime().toString();
        //Change the text in the textView to the current system time
        timeTextView.setText(time);

    }

    public void saveNote(View view) {
        //After clicking the save button, transfer the new Note back to the MainActivity
        String title = titleEditText.getText().toString();
        String time = timeTextView.getText().toString();
        String message = "No message";
        //If the edit text is empty, give the text a default value
        if(title.isEmpty()){
            title = "No title";
        }
        if(message.isEmpty()){
            message = "No message";
        }
        Note note = new Note(title, time, message);
        Intent intent = new Intent();
        intent.putExtra("New Note", note);
        setResult(RESULT_OK, intent);
        finish();

    }

    public void cancelAdd(View view) {
        //After clicking the cancel button, pop up a dialog to ask the user whether to give up this edit
        AlertDialog.Builder builder = new AlertDialog.Builder(EditActivity.this);
        builder.setTitle(R.string.dialog_cancel_title).setMessage(R.string.dialog_cancel_msg)
                .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //Give up this edit
                        finish();

                    }
                }).setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                //User cancelled the dialog
                //Continue to edit the new note
            }
        });
        builder.create().show();

    }
}
