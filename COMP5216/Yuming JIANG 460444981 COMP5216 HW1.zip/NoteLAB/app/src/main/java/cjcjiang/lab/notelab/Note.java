package cjcjiang.lab.notelab;

import com.orm.SugarRecord;

import java.io.Serializable;

/**
 * Created by cjcji on 2016/8/29.
 */
public class Note extends SugarRecord implements Serializable {

    private static final long serialVersionUID = 666;

    private String title;
    private String time;
    private String message;

    public Note(){

    }

    public Note(String title, String time, String message){
        this.title = title;
        this.time = time;
        this.message = message;
    }

    public String getTitle(){
        return this.title;
    }

    public String getTime(){
        return this.time;
    }

    public String getMessage(){
        return this.message;
    }

}
