package cjcjiang.lab.notelab;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.GridView;
import android.widget.Switch;

import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import com.facebook.FacebookSdk;



public class MainActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener{

    private ArrayList<Note> arrayOfNotes;
    //ListView listView;
    private UsersAdapter adapter;
    private GridView gridView;
    private Button addNewButton;

    private Switch switchDisplay;

    //Number to store the current location with latitude and longitude
    private double currentLatitude;
    private double currentLongitude;

    //This request code is for the Add New button
    private final int REQUEST_CODE = 233;

    //private static final int REQUEST_READ_EXTERNAL_STORAGE = 601;
    //This code is used to get the permission of using camera, storage and location in this app from the user
    private static final int REQUEST_PERMISSION = 602;

    //Explicitly get the permission of using location
    private static final int REQUEST_ACCESS_FINE_LOCATION = 605;
    //Explicitly get the permission of using camera
    //private static final int REQUEST_CAMERA= 606;

    //This code is used for checking the usability of google services
    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 1000;
    private static final String TAG = MainActivity.class.getSimpleName();
    //Store the location got from google api
    private Location mLastLocation;
    private GoogleApiClient mGoogleApiClient;

    //Initialize things used for facebook login
    CallbackManager callbackManager;
    private LoginButton loginButton;
    private AccessToken accessToken;
    private AccessTokenTracker accessTokenTracker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //Initialize facebook sdk
        FacebookSdk.sdkInitialize(getApplicationContext());

        //Use Fresco to load the image, so initialize Fresco here
        Fresco.initialize(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get the permission of using camera, storage and location in this app from the user
        int permission = ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        if (permission != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMISSION );
        }

        //Initialize the arraylist to store notes in the mainActivity
        arrayOfNotes = new ArrayList<Note>();

        //Get all of the notes from the database
        readNotesFromDatabase();

        //Check the usability of google services
        if (checkPlayServices()) {

            // If google services can be used, build the GoogleApi client
            buildGoogleApiClient();
        }
        //Get the current location
        getCurrentLocation();

        // Create the adapter to convert the array to views
        adapter = new UsersAdapter(this, arrayOfNotes);

        //Show the notes in this gridView
        gridView = (GridView) findViewById(R.id.gridview);
        gridView.setAdapter(adapter);

        //Pop up a dialog asking confirmation on deleting when user long click
        setupGridViewListener();

        //Set the initial status of the switch off
        switchDisplay = (Switch) findViewById(R.id.switchDisplay);
        switchDisplay.setChecked(false);

        //Switch off: 3 columns, switch on: 1 column with sorting
        setupSwitchDisplayOnCheckedChangeListener();

        //Clicking on this button will jump to editActivity and start adding new note
        addNewButton = (Button) findViewById(R.id.addNewButton);

        //Hiding the information of notes before user login with facebook
        gridView.setVisibility(GONE);
        switchDisplay.setVisibility(GONE);
        addNewButton.setVisibility(GONE);

        //Check if the user have already login, if yes, just show all the things directly
        if(isLoggedIn()){
            gridView.setVisibility(VISIBLE);
            switchDisplay.setVisibility(VISIBLE);
            addNewButton.setVisibility(VISIBLE);
        }

        //To login with facebook
        callbackManager = CallbackManager.Factory.create();
        loginButton = (LoginButton) findViewById(R.id.login_button);

        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {

            //Login success

            @Override
            public void onSuccess(LoginResult loginResult) {
                accessToken = loginResult.getAccessToken();

                Log.d("FB","access token got.");

                //If login success, show the notes and other UI to the user
                gridView.setVisibility(VISIBLE);
                switchDisplay.setVisibility(VISIBLE);
                addNewButton.setVisibility(VISIBLE);
            }

            //Login canceled, do nothing

            @Override
            public void onCancel() {
                // App code

                Log.d("FB","CANCEL");
            }

            //Login fail, do nothing

            @Override
            public void onError(FacebookException exception) {
                // App code

                Log.d("FB",exception.toString());
            }
        });

        //When the user logout of facebook, the notes and ui will be hidden
        accessTokenTracker = new AccessTokenTracker() {
            @Override
            protected void onCurrentAccessTokenChanged(AccessToken oldAccessToken,
                                                       AccessToken currentAccessToken) {
                if (currentAccessToken == null) {
                    gridView.setVisibility(GONE);
                    switchDisplay.setVisibility(GONE);
                    addNewButton.setVisibility(GONE);
                }
            }
        };
    }

    //Used to check if the user have already login, if yes, return TRUE
    public boolean isLoggedIn() {
        AccessToken accessToken = AccessToken.getCurrentAccessToken();
        return accessToken != null;
    }

    //When AddNew button is clicked, this method will be invoked
    public void addNewNote(View view) {
        // Jump to the EditActivity
        Intent intent = new Intent(this, EditActivity.class);
        startActivityForResult(intent, REQUEST_CODE);
    }

    //Sort the notes with the distance between the location stored in the note and the current location
    public void sortNotes() {
        getCurrentLocation();
        ArrayList<NoteDistanceCompare> arrayOfNotesDistanceCompare = new ArrayList<NoteDistanceCompare>();
        Iterator<Note> itr = arrayOfNotes.iterator();
        //Get all of the notes out and put them in the NoteDistanceCompare object to make the comparison easier
        while (itr.hasNext()) {
            NoteDistanceCompare noteDisComp = new NoteDistanceCompare(itr.next(), currentLatitude, currentLongitude);
            arrayOfNotesDistanceCompare.add(noteDisComp);
        }

        Collections.sort(arrayOfNotesDistanceCompare, new Comparator<NoteDistanceCompare>() {
            @Override
            public int compare(NoteDistanceCompare noteDistanceCompare, NoteDistanceCompare t1) {
                //Calculate the distance and the difference
                double temp = noteDistanceCompare.getDistance() - t1.getDistance();
                if (temp>0){
                    //If noteDistanceCompare is far than t1, return 1
                    return 1;
                }
                if (temp<0){
                    //If t1 is far than noteDistanceCompare, return -1
                    return -1;
                }
                //If they have the same distance, return 0
                return 0;
            }
        });

        //Clear the notes showed in gridView first
        arrayOfNotes.clear();
        ArrayList<Note> arrayOfNotes2 = new ArrayList<Note>();
        //Put the sorted notes in the new arrayList
        Iterator<NoteDistanceCompare> itr2 = arrayOfNotesDistanceCompare.iterator();
        while (itr2.hasNext()) {
            Note note = itr2.next().getNote();
            arrayOfNotes2.add(note);
        }

        //Update the notes that will be showed in the gridView with sorted notes
        arrayOfNotes.addAll(arrayOfNotes2);
        //Show the changing of notes in the gridView
        adapter.notifyDataSetChanged();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        // To receive the new note transfered from the EditActivity
        if (resultCode == RESULT_OK && requestCode == REQUEST_CODE) {
            // Extract the new note from the intent
            Note note = (Note)intent.getSerializableExtra("New Note");
            arrayOfNotes.add(note);
            //Save the new note to the database
            saveNotesToDatabase();
            //Refresh the listView to display the new note
            adapter.notifyDataSetChanged();

        }

        //Handle the callback of facebook
        callbackManager.onActivityResult(requestCode, resultCode, intent);

    }

    //read saved notes from the database
    private void readNotesFromDatabase() {
        List<Note> notesFromORM = Note.listAll(Note.class);
        ArrayList<Note> arrayOfNotes2 = new ArrayList<Note>();
        //arrayOfNotes = new ArrayList<Note>();
        arrayOfNotes.clear();
        if (notesFromORM != null & notesFromORM.size() > 0) {
            for (Note note : notesFromORM) {
                arrayOfNotes2.add(note);
            }
        }
        arrayOfNotes.addAll(arrayOfNotes2);
    }

    //save all the notes to the database
    private void saveNotesToDatabase() {
        Note.deleteAll(Note.class);
        for (Note note:arrayOfNotes){
            note.save();
        }
    }

    //Listening to the status of the switch
    private void setupSwitchDisplayOnCheckedChangeListener(){
        switchDisplay.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {

                if(isChecked){
                    changeNumColumns(1);
                    sortNotes();
                }else{
                    ArrayList<Note> arrayOfNotes2 = new ArrayList<Note>();
                    readNotesFromDatabase();
                    adapter.notifyDataSetChanged();
                    changeNumColumns(3);
                }

            }
        });
    }

    //Change the number of columns of the gridView
    public void changeNumColumns(int numOfColunmns) {
        gridView.setNumColumns(numOfColunmns);
    }

    //When user longclick on the note in the gridView, this method will be invoked
    private void setupGridViewListener() {

        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            //When user long click the note, show this dialog
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long rowId) {
                Log.i("MainActivity", "Long Clicked item " + position);
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle(R.string.dialog_delete_title).setMessage(R.string.dialog_delete_msg)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //Delete the note
                                arrayOfNotes.remove(position);
                                adapter.notifyDataSetChanged();
                                saveNotesToDatabase();

                            }
                        }).setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //User cancelled the dialog
                        // nothing happens
                    }
                });
                builder.create().show();
                return true;
            }
        });
    }

    //Check if the google play services are available on this phone
    private boolean checkPlayServices() {
        GoogleApiAvailability googleAPI = GoogleApiAvailability.getInstance();
        int result = googleAPI.isGooglePlayServicesAvailable(this);
        if(result != ConnectionResult.SUCCESS) {
            if(googleAPI.isUserResolvableError(result)) {
                googleAPI.getErrorDialog(this, result,
                        PLAY_SERVICES_RESOLUTION_REQUEST).show();
            }

            return false;
        }

        return true;
    }

    //Build the google api client to get the location
    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        checkPlayServices();
    }

    @Override
    public void onConnectionFailed(ConnectionResult result) {
        Log.i(TAG, "Connection failed: ConnectionResult.getErrorCode() = "
                + result.getErrorCode());
    }

    @Override
    public void onConnected(Bundle arg0) {

        // Once connected with google api, get the location
        getCurrentLocation();
    }

    @Override
    public void onConnectionSuspended(int arg0) {
        mGoogleApiClient.connect();
    }

    private void getCurrentLocation() {

        int permission = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        if (permission != PackageManager.PERMISSION_GRANTED) {
            //Get the permission of the location
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_ACCESS_FINE_LOCATION );
        }

        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

        if (mLastLocation != null) {
            currentLatitude = mLastLocation.getLatitude();
            currentLongitude = mLastLocation.getLongitude();
        }
    }



}
