package cjcjiang.lab.notelab;

import android.net.Uri;

import com.orm.SugarRecord;

import java.io.Serializable;


/**
 * Created by cjcji on 2016/8/29.
 */
public class Note extends SugarRecord implements Serializable {

    private static final long serialVersionUID = 666;

    private String title;
    private String time;
    private String message;
    private String imageURI;
    private double latitude;
    private double longitude;

    public Note(){

    }

    public Note(String title, String time, String message, String imageURI, double latitude, double longitude){
        this.title = title;
        this.time = time;
        this.message = message;
        this.imageURI = imageURI;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getTitle(){
        return this.title;
    }

    public String getTime(){
        return this.time;
    }

    public String getMessage(){
        return this.message;
    }

    public String getImageURI(){
        return this.imageURI;
    }

    public double getLatitude(){
        return this.latitude;
    }

    public double getLongitude(){
        return this.longitude;
    }

    public void setTitle(String title){
        this.title = title;
    }

    public void setTime(String time){
        this.time = time;
    }

    public void setMessage(String message){
        this.message = message;
    }

    public void setImageURI(String imageURI){
        this.imageURI = imageURI;
    }

    public void setLatitude(double latitude){
        this.latitude = latitude;
    }

    public void setLongitude(double longitude){
        this.longitude = longitude;
    }


}
