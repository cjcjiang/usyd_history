package cjcjiang.lab.notelab;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Calendar;

public class EditActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

    public final String APP_TAG = "NoteLAB";
    public final static int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 1034;
    public final static int PICK_PHOTO_CODE = 1046;

    private static final String TAG = EditActivity.class.getSimpleName();
    private static final int REQUEST_ACCESS_FINE_LOCATION = 605;
    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 1000;
    private Location mLastLocation;
    private GoogleApiClient mGoogleApiClient;

    public String photoFileName = "photo";

    EditText titleEditText;
    EditText messageEditText;
    TextView timeTextView;
    Calendar timeOfCreation;

    TextView locationTextView;

    String title;
    String time;
    String message;
    double latitude;
    double longitude;
    String imageURI = "https://www.enterprise.com/content/dam/global-vehicle-images/cars/FORD_FOCU_2012-1.png";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        titleEditText = (EditText)findViewById(R.id.title_editText);

        timeTextView = (TextView) findViewById(R.id.time_textView);

        locationTextView = (TextView) findViewById(R.id.location_textView);

        //Use calendar to get the current system time
        timeOfCreation = Calendar.getInstance();
        time = timeOfCreation.getTime().toString();
        //Change the text in the textView to the current system time
        timeTextView.setText(time);

        if (checkPlayServices()) {

            // Building the GoogleApi client
            buildGoogleApiClient();
        }
        displayLocation();

    }

    //When the user click on the loadPhoto button, this method will be invoked
    public void onLoadPhotoClick(View view) {
        // Create intent for picking a photo from the gallery
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        // Bring up gallery to select a photo
        startActivityForResult(intent, PICK_PHOTO_CODE);
    }

    //When user click on the takePhoto button, this method will be invoked
    public void onTakePhotoClick(View v) {
        // create Intent to take a picture and return control to the calling application
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        String photoDir = photoFileName + time + ".jpg";
        intent.putExtra(MediaStore.EXTRA_OUTPUT, getFileUri(photoDir)); // set file name

        // Start the image capture intent to take photo
        startActivityForResult(intent, CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);
    }

    //Get uri of the photo
    public Uri getFileUri(String fileName) {
        // Get safe storage directory for photos
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), APP_TAG);

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists() && !mediaStorageDir.mkdirs()) {
            Log.d(APP_TAG, "failed to create directory");
        }

        // Return the file target for the photo based on filename
        return Uri.fromFile(new File(mediaStorageDir.getPath() + File.separator
                + fileName));
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        ImageView ivPreview = (ImageView) findViewById(R.id.photopreview);
        if (requestCode == CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                String photoDir = photoFileName + time + ".jpg";
                Uri takenPhotoUri = getFileUri(photoDir);

                //Preparing the uri of the takenPhoto for storing in the note
                imageURI = takenPhotoUri.toString();

                // by this point we have the camera photo on disk
                Bitmap takenImage = BitmapFactory.decodeFile(takenPhotoUri
                        .getPath());
                // Load the taken image into a preview
                ivPreview.setImageBitmap(takenImage);
                //ivPreview.setVisibility(View.VISIBLE);
            } else { // Result was a failure
                Toast.makeText(this, "Picture wasn't taken!",
                        Toast.LENGTH_SHORT).show();
            }
        }
        else if (requestCode == PICK_PHOTO_CODE) {
            if (resultCode == RESULT_OK) {
                Uri photoUri = data.getData();

                //Preparing the uri of the loadPhoto for storing in the note
                imageURI = photoUri.toString();

                // Do something with the photo based on Uri
                Bitmap selectedImage;
                try {
                    selectedImage = MediaStore.Images.Media.getBitmap(
                            this.getContentResolver(), photoUri);
                    // Load the selected image into a preview

                    ivPreview.setImageBitmap(selectedImage);
                    //ivPreview.setVisibility(View.VISIBLE);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //Save the note
    public void saveNote(View view) {
        //After clicking the save button, transfer the new Note back to the MainActivity
        title = titleEditText.getText().toString();
        time = timeTextView.getText().toString();
        message = "No message";
        //If the edit text is empty, give the text a default value
        if(title.isEmpty()){
            title = "No title";
        }
        if(message.isEmpty()){
            message = "No message";
        }
        if(imageURI.isEmpty()){
            imageURI = "https://www.enterprise.com/content/dam/global-vehicle-images/cars/FORD_FOCU_2012-1.png";
        }
        Note note = new Note(title, time, message, imageURI, latitude, longitude);
        Intent intent = new Intent();
        intent.putExtra("New Note", note);
        setResult(RESULT_OK, intent);
        finish();

    }

    //Cancel the adding, and return to the mainActivity
    public void cancelAdd(View view) {
        //After clicking the cancel button, pop up a dialog to ask the user whether to give up this edit
        AlertDialog.Builder builder = new AlertDialog.Builder(EditActivity.this);
        builder.setTitle(R.string.dialog_cancel_title).setMessage(R.string.dialog_cancel_msg)
                .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //Give up this edit
                        finish();

                    }
                }).setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                //User cancelled the dialog
                //Continue to edit the new note
            }
        });
        builder.create().show();

    }

    ////Check if the google play services are available on this phone
    private boolean checkPlayServices() {
        GoogleApiAvailability googleAPI = GoogleApiAvailability.getInstance();
        int result = googleAPI.isGooglePlayServicesAvailable(this);
        if(result != ConnectionResult.SUCCESS) {
            if(googleAPI.isUserResolvableError(result)) {
                googleAPI.getErrorDialog(this, result,
                        PLAY_SERVICES_RESOLUTION_REQUEST).show();
            }

            return false;
        }

        return true;
    }

    //Build the google api client to get the location
    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
    }

    //Display the location of the creation of the new note
    private void displayLocation() {
        int permission = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        if (permission != PackageManager.PERMISSION_GRANTED) {
            //Get the permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_ACCESS_FINE_LOCATION );
        }
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (mLastLocation != null) {
            latitude = mLastLocation.getLatitude();
            longitude = mLastLocation.getLongitude();
            locationTextView.setText("Latitude:" + latitude + ", Longitude:" + longitude);
        } else {
            locationTextView
                    .setText("(Couldn't get the location. Make sure location is enabled on the device)");
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        checkPlayServices();
    }

    @Override
    public void onConnectionFailed(ConnectionResult result) {
        Log.i(TAG, "Connection failed: ConnectionResult.getErrorCode() = "
                + result.getErrorCode());
    }

    @Override
    public void onConnected(Bundle arg0) {

        // Once connected with google api, get the location
        displayLocation();
    }

    @Override
    public void onConnectionSuspended(int arg0) {
        mGoogleApiClient.connect();
    }


}
