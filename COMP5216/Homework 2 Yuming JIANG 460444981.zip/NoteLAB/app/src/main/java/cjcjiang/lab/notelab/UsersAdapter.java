package cjcjiang.lab.notelab;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;

import java.util.ArrayList;

/**
 * Created by JIANG on 2016/9/4.
 */
public class UsersAdapter extends ArrayAdapter<Note> {
    public UsersAdapter(Context context, ArrayList<Note> notes) {
        super(context, 0, notes);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Note note = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_note, parent, false);
        }
        // Lookup view for data population
        TextView note_titleTextView = (TextView) convertView.findViewById(R.id.note_titleTextView);
        //TextView note_timeTextView = (TextView) convertView.findViewById(R.id.note_timeTextView);

        //Get the image view
        SimpleDraweeView draweeView = (SimpleDraweeView) convertView.findViewById(R.id.note_image_view);

        // Populate the data into the template view using the data object
        note_titleTextView.setText(note.getTitle());
        //note_timeTextView.setText(note.getTime());

        //Show the stored image in the note
        Uri uri = Uri.parse(note.getImageURI());
        draweeView.setImageURI(uri);

        // Return the completed view to render on screen
        return convertView;
    }
}
